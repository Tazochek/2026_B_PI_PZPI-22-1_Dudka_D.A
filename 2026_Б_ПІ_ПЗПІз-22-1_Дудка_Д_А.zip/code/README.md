# LogiTime — облік витрат часу логістичного підприємства

Вебсистема на Django для обліку робочого часу за логістичними замовленнями. Працівник вносить години за задачею, менеджер погоджує або відхиляє запис, а система фіксує ставку, розраховує вартість і формує XLSX-звіт.

## Можливості

- клієнти, логістичні замовлення, маршрути та задачі;
- ролі адміністратора, менеджера, працівника й бухгалтера;
- призначення працівників до замовлень;
- чернетка → подання → погодження/відхилення;
- незмінність погодженого запису та журнал аудиту;
- розрахунок `вартість = години × зафіксована ставка` через `Decimal`;
- звіт за період і експорт `.xlsx`;
- object-level перевірки доступу на сервері.

## Локальний запуск

Команди виконуються з папки `code/`.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Завантажте значення `.env` у PowerShell і виберіть SQLite для локальної демонстрації:

```powershell
Get-Content .env | Where-Object { $_ -match '^[^#].+=' } | ForEach-Object {
    $name, $value = $_ -split '=', 2
    Set-Item -Path "Env:$name" -Value $value
}
$env:DJANGO_DB_ENGINE='sqlite'
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

Демонстраційний пароль: `DemoPass2026!`.

| Роль | Логін |
|---|---|
| Адміністратор | `demo_admin` |
| Менеджер | `demo_manager` |
| Працівник | `demo_employee` |
| Водій | `demo_driver` |
| Бухгалтер | `demo_accountant` |

Основні URL: `/operations/orders/`, `/time/my/`, `/time/approvals/`, `/time/report/`.

## Модель даних

```mermaid
erDiagram
    User ||--o| EmployeeProfile : "має профіль"
    User ||--o{ LogisticsOrder : "керує"
    Client ||--o{ LogisticsOrder : "замовляє"
    LogisticsOrder }o--o{ EmployeeProfile : "призначає"
    LogisticsOrder ||--o{ OrderTask : "містить"
    EmployeeProfile ||--o{ TimeEntry : "фіксує"
    OrderTask ||--o{ TimeEntry : "обліковує"
    TimeEntry ||--o{ TimeEntryHistory : "аудит"
    User ||--o{ TimeEntryHistory : "виконує дію"
```

`hourly_rate_snapshot` зберігає ставку на момент створення запису, тому зміна ставки працівника не переписує історичну вартість. Погоджений запис не редагується; коригування виконується через відхилення до погодження.

## Тести

```powershell
$env:DJANGO_SECRET_KEY='test-key'
$env:DJANGO_DB_ENGINE='sqlite'
$env:DJANGO_DEBUG='true'
python manage.py check --settings=config.test_settings
python manage.py test --settings=config.test_settings
```

Тести перевіряють розрахунок вартості, діапазон годин, призначення працівника, незмінність погодженого запису, доступ до чужих об'єктів, повноваження менеджера, XLSX-експорт та ідемпотентність `seed_demo`.

## Production

Приклад розгортання розрахований на Ubuntu, `/var/www/logitime`, PostgreSQL 16, Gunicorn, systemd, Nginx і TLS. Секрети зберігаються в `/etc/logitime.env`, а не в репозиторії.

```bash
cd /var/www/logitime/code
set -a; source /etc/logitime.env; set +a
../.venv/bin/python manage.py migrate
../.venv/bin/python manage.py collectstatic --noinput
sudo cp deploy/gunicorn.service /etc/systemd/system/logitime.service
sudo systemctl enable --now logitime
```

Перед запуском замініть `logitime.example.com` у `deploy/nginx.conf`, отримайте TLS-сертифікат і налаштуйте щоденний запуск `deploy/backup_db.sh`. Скрипт зберігає дампи 30 днів; відновлення потребує явного введення `ВІДНОВИТИ`.

## Демонстраційний сценарій

1. Увійти як `demo_manager`, відкрити `ORD-2026-001` і показати задачі та працівників.
2. Увійти як `demo_employee`, створити запис 2,5 години на задачу «Оформлення документів» і подати його.
3. Увійти як `demo_manager`, погодити запис.
4. Відкрити звіт і завантажити XLSX з працівником, замовленням, годинами, ставкою та вартістю.
