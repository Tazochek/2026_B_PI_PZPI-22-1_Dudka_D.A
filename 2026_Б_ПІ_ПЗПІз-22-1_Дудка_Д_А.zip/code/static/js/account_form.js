document.addEventListener("DOMContentLoaded", () => {
    const role = document.querySelector("#id_role");
    const fields = document.querySelectorAll(".employee-fields");
    const sync = () => fields.forEach((field) => {
        field.hidden = role && role.value === "admin";
    });
    if (role) role.addEventListener("change", sync);
    sync();
});
