#!/usr/bin/env bash
# Відновлює PostgreSQL лише після явного підтвердження оператора.
set -euo pipefail

if [[ $# -ne 1 ]]; then
    echo "Використання: $0 /шлях/до/logitime_YYYY-MM-DD_HH-MM-SS.dump" >&2
    exit 1
fi

dump_file="$1"
ENV_FILE="${ENV_FILE:-/etc/logitime.env}"

if [[ ! -f "$dump_file" ]]; then
    echo "Файл дампа не знайдено: $dump_file" >&2
    exit 1
fi
if [[ ! -f "$ENV_FILE" ]]; then
    echo "Не знайдено файл змінних: $ENV_FILE" >&2
    exit 1
fi

set -a
source "$ENV_FILE"
set +a

: "${POSTGRES_DB:?Не задано POSTGRES_DB}"
: "${POSTGRES_USER:?Не задано POSTGRES_USER}"
: "${POSTGRES_PASSWORD:?Не задано POSTGRES_PASSWORD}"
: "${POSTGRES_HOST:?Не задано POSTGRES_HOST}"
: "${POSTGRES_PORT:?Не задано POSTGRES_PORT}"

echo "Базу $POSTGRES_DB буде очищено та відновлено з $dump_file."
read -r -p "Введіть ВІДНОВИТИ для продовження: " confirmation
if [[ "$confirmation" != "ВІДНОВИТИ" ]]; then
    echo "Відновлення скасовано."
    exit 0
fi

PGPASSWORD="$POSTGRES_PASSWORD" pg_restore \
    --host="$POSTGRES_HOST" \
    --port="$POSTGRES_PORT" \
    --username="$POSTGRES_USER" \
    --dbname="$POSTGRES_DB" \
    --clean \
    --if-exists \
    --no-owner \
    "$dump_file"

echo "Базу відновлено. Виконайте python manage.py migrate для перевірки схеми."
