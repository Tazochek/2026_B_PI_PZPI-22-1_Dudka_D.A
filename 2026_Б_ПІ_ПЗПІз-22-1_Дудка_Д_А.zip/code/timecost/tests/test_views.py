from datetime import date
from decimal import Decimal

from django.urls import reverse

from timecost.models import TimeEntry

from .base import LogisticsTestCase


class TimeEntryViewTests(LogisticsTestCase):
    def setUp(self):
        self.entry = TimeEntry.objects.create(
            employee=self.employee.employee_profile,
            task=self.task,
            work_date=date.today(),
            hours=Decimal("2.50"),
        )

    def test_employee_cannot_open_another_employees_entry(self):
        self.client.force_login(self.other_employee)
        response = self.client.get(reverse("timecost:entry_update", args=(self.entry.pk,)))
        self.assertEqual(response.status_code, 404)

    def test_manager_only_sees_submissions_for_own_orders(self):
        self.entry.submit(self.employee)
        self.client.force_login(self.other_manager)
        response = self.client.get(reverse("timecost:approvals"))
        self.assertNotContains(response, "Оформлення документів")

    def test_employee_can_submit_own_draft(self):
        self.client.force_login(self.employee)
        response = self.client.post(reverse("timecost:entry_submit", args=(self.entry.pk,)))
        self.assertRedirects(response, reverse("timecost:my_entries"))
        self.entry.refresh_from_db()
        self.assertEqual(self.entry.status, TimeEntry.Status.SUBMITTED)

    def test_accountant_can_download_xlsx_report(self):
        self.client.force_login(self.accountant)
        response = self.client.get(reverse("timecost:report_xlsx"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response["Content-Type"],
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.assertGreater(len(response.content), 4000)
