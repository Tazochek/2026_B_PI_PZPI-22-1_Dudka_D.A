from datetime import date
from decimal import Decimal

from django.core.exceptions import ValidationError

from timecost.models import TimeEntry

from .base import LogisticsTestCase


class TimeEntryModelTests(LogisticsTestCase):
    def make_entry(self, **overrides):
        values = {
            "employee": self.employee.employee_profile,
            "task": self.task,
            "work_date": date.today(),
            "hours": Decimal("2.50"),
        }
        values.update(overrides)
        return TimeEntry(**values)

    def test_cost_uses_decimal_rate_snapshot(self):
        entry = self.make_entry()
        entry.save()
        self.assertEqual(entry.hourly_rate_snapshot, Decimal("280.00"))
        self.assertEqual(entry.cost, Decimal("700.00"))

    def test_hours_must_be_positive_and_not_exceed_24(self):
        for hours in (Decimal("0"), Decimal("-1"), Decimal("24.01")):
            with self.subTest(hours=hours), self.assertRaises(ValidationError):
                self.make_entry(hours=hours).save()

    def test_employee_must_be_assigned_to_order(self):
        with self.assertRaises(ValidationError):
            self.make_entry(employee=self.other_employee.employee_profile).save()

    def test_approved_entry_is_immutable(self):
        entry = self.make_entry()
        entry.save()
        entry.submit(self.employee)
        entry.review(self.manager, approve=True)
        entry.hours = Decimal("3.00")
        with self.assertRaises(ValidationError):
            entry.save()

    def test_foreign_manager_cannot_review_entry(self):
        entry = self.make_entry()
        entry.save()
        entry.submit(self.employee)
        with self.assertRaises(ValidationError):
            entry.review(self.other_manager, approve=True)
