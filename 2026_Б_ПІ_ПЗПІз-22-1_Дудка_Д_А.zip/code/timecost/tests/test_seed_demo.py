from django.core.management import call_command
from django.test import TestCase

from accounts.models import User
from operations.models import LogisticsOrder
from timecost.models import TimeEntry


class SeedDemoTests(TestCase):
    def test_seed_is_idempotent(self):
        call_command("seed_demo", verbosity=0)
        call_command("seed_demo", verbosity=0)
        self.assertEqual(User.objects.filter(username__startswith="demo_").count(), 5)
        self.assertEqual(LogisticsOrder.objects.filter(order_number="ORD-2026-001").count(), 1)
        self.assertEqual(TimeEntry.objects.count(), 3)
