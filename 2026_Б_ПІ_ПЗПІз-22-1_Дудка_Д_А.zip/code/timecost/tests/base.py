from datetime import date, timedelta
from decimal import Decimal

from django.test import TestCase

from accounts.models import User
from operations.models import Client, LogisticsOrder, OrderTask


class LogisticsTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.manager = User.objects.create_account(
            username="manager",
            email="manager@example.com",
            password="StrongPass2026!",
            role=User.Role.MANAGER,
            profile_data={
                "first_name": "Олена",
                "last_name": "Коваль",
                "employee_number": "MGR-001",
                "position": "Менеджер",
                "hourly_rate": Decimal("400.00"),
            },
        )
        cls.other_manager = User.objects.create_account(
            username="manager2",
            email="manager2@example.com",
            password="StrongPass2026!",
            role=User.Role.MANAGER,
            profile_data={
                "first_name": "Іван",
                "last_name": "Петренко",
                "employee_number": "MGR-002",
                "position": "Менеджер",
                "hourly_rate": Decimal("410.00"),
            },
        )
        cls.employee = User.objects.create_account(
            username="employee",
            email="employee@example.com",
            password="StrongPass2026!",
            role=User.Role.EMPLOYEE,
            profile_data={
                "first_name": "Андрій",
                "last_name": "Мельник",
                "employee_number": "EMP-001",
                "position": "Логіст",
                "hourly_rate": Decimal("280.00"),
            },
        )
        cls.other_employee = User.objects.create_account(
            username="employee2",
            email="employee2@example.com",
            password="StrongPass2026!",
            role=User.Role.EMPLOYEE,
            profile_data={
                "first_name": "Сергій",
                "last_name": "Бондар",
                "employee_number": "EMP-002",
                "position": "Водій",
                "hourly_rate": Decimal("320.00"),
            },
        )
        cls.accountant = User.objects.create_account(
            username="accountant",
            email="accountant@example.com",
            password="StrongPass2026!",
            role=User.Role.ACCOUNTANT,
            profile_data={
                "first_name": "Ірина",
                "last_name": "Ткаченко",
                "employee_number": "ACC-001",
                "position": "Бухгалтер",
                "hourly_rate": Decimal("350.00"),
            },
        )
        cls.client_record = Client.objects.create(name="ТОВ Тест")
        cls.order = LogisticsOrder.objects.create(
            order_number="ORD-TEST-001",
            client=cls.client_record,
            route="Харків — Київ",
            status=LogisticsOrder.Status.IN_PROGRESS,
            manager=cls.manager,
            planned_start=date.today() - timedelta(days=1),
            planned_end=date.today() + timedelta(days=1),
        )
        cls.order.assigned_employees.add(cls.employee.employee_profile)
        cls.task = OrderTask.objects.create(
            order=cls.order,
            title="Оформлення документів",
            estimated_hours=Decimal("5.00"),
        )
