from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


def build_time_cost_report(entries):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Витрати часу"
    headers = [
        "Дата",
        "Замовлення",
        "Клієнт",
        "Задача",
        "Працівник",
        "Табельний №",
        "Години",
        "Ставка, грн/год",
        "Вартість, грн",
        "Статус",
    ]
    worksheet.append(headers)
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for entry in entries.select_related("employee", "task__order__client"):
        worksheet.append(
            [
                entry.work_date,
                entry.task.order.order_number,
                entry.task.order.client.name,
                entry.task.title,
                entry.employee.full_name,
                entry.employee.employee_number,
                float(entry.hours),
                float(entry.hourly_rate_snapshot),
                float(entry.cost),
                entry.get_status_display(),
            ]
        )

    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions
    widths = [13, 17, 24, 28, 30, 15, 11, 18, 18, 16]
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = width
    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    for cell in worksheet["G"][1:]:
        cell.number_format = "0.00"
    for column in ("H", "I"):
        for cell in worksheet[column][1:]:
            cell.number_format = '#,##0.00" грн"'

    output = BytesIO()
    workbook.save(output)
    return output.getvalue()
