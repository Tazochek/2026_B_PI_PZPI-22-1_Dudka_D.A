from django import forms

from operations.models import LogisticsOrder, OrderTask

from .models import TimeEntry


class TimeEntryForm(forms.ModelForm):
    class Meta:
        model = TimeEntry
        fields = ("task", "work_date", "hours", "comment")
        widgets = {
            "work_date": forms.DateInput(attrs={"type": "date"}),
            "hours": forms.NumberInput(attrs={"min": "0.25", "max": "24", "step": "0.25"}),
            "comment": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, employee=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.employee = employee
        if employee:
            self.fields["task"].queryset = OrderTask.objects.filter(
                order__assigned_employees=employee,
                order__status__in=(LogisticsOrder.Status.PLANNED, LogisticsOrder.Status.IN_PROGRESS),
            ).select_related("order", "order__client").distinct()

    def save(self, commit=True):
        entry = super().save(commit=False)
        if self.employee:
            entry.employee = self.employee
        if commit:
            entry.save()
        return entry


class ReviewForm(forms.Form):
    decision = forms.ChoiceField(
        label="Рішення",
        choices=(("approve", "Погодити"), ("reject", "Відхилити")),
        widget=forms.RadioSelect,
    )
    note = forms.CharField(
        label="Коментар менеджера",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("decision") == "reject" and not cleaned.get("note", "").strip():
            self.add_error("note", "Для відхилення вкажіть причину.")
        return cleaned


class ReportFilterForm(forms.Form):
    date_from = forms.DateField(
        label="Початкова дата", required=False, widget=forms.DateInput(attrs={"type": "date"})
    )
    date_to = forms.DateField(
        label="Кінцева дата", required=False, widget=forms.DateInput(attrs={"type": "date"})
    )
    status = forms.ChoiceField(
        label="Статус",
        required=False,
        choices=(("", "Усі статуси"),) + tuple(TimeEntry.Status.choices),
    )

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("date_from") and cleaned.get("date_to") and cleaned["date_to"] < cleaned["date_from"]:
            self.add_error("date_to", "Кінцева дата не може передувати початковій.")
        return cleaned
