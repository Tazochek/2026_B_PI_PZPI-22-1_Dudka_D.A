from django.apps import AppConfig


class TimecostConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "timecost"
    verbose_name = "Облік витрат часу"
