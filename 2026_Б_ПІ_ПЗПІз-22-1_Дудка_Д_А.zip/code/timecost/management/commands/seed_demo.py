from datetime import date, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from accounts.models import EmployeeProfile, User
from operations.models import Client, LogisticsOrder, OrderTask
from timecost.models import TimeEntry, TimeEntryHistory


DEMO_PASSWORD = "DemoPass2026!"


class Command(BaseCommand):
    help = "Створює ідемпотентні демонстраційні дані логістичної системи."

    @transaction.atomic
    def handle(self, *args, **options):
        admin = self.ensure_user("demo_admin", User.Role.ADMIN, "Адміністратор", "ADM-001", Decimal("0"))
        manager = self.ensure_user("demo_manager", User.Role.MANAGER, "Менеджер логістики", "MGR-001", Decimal("420"))
        employee1 = self.ensure_user("demo_employee", User.Role.EMPLOYEE, "Логіст", "EMP-001", Decimal("280"))
        employee2 = self.ensure_user("demo_driver", User.Role.EMPLOYEE, "Водій-експедитор", "EMP-002", Decimal("320"))
        accountant = self.ensure_user("demo_accountant", User.Role.ACCOUNTANT, "Бухгалтер", "ACC-001", Decimal("350"))

        client, _ = Client.objects.update_or_create(
            name="ТОВ «Північ Трейд»",
            defaults={
                "tax_id": "41234567",
                "contact_person": "Марія Коваленко",
                "phone": "+380 44 555 01 20",
                "email": "office@north-trade.example",
            },
        )
        today = date.today()
        order, _ = LogisticsOrder.objects.update_or_create(
            order_number="ORD-2026-001",
            defaults={
                "client": client,
                "route": "Харків — Полтава — Київ",
                "description": "Доставка палетованого вантажу з контролем документів і строків.",
                "status": LogisticsOrder.Status.IN_PROGRESS,
                "manager": manager,
                "planned_start": today - timedelta(days=4),
                "planned_end": today + timedelta(days=2),
            },
        )
        order.assigned_employees.set([employee1.employee_profile, employee2.employee_profile])

        task_specs = (
            ("Планування маршруту", "Підготувати маршрут, контрольні точки та резервний варіант.", "4.00", OrderTask.Status.DONE),
            ("Оформлення документів", "Перевірити ТТН, супровідні документи та дані одержувача.", "6.00", OrderTask.Status.IN_PROGRESS),
            ("Контроль доставки", "Контролювати проходження контрольних точок і строки.", "12.00", OrderTask.Status.IN_PROGRESS),
        )
        tasks = {}
        for title, description, hours, status in task_specs:
            task, _ = OrderTask.objects.update_or_create(
                order=order,
                title=title,
                defaults={"description": description, "estimated_hours": Decimal(hours), "status": status},
            )
            tasks[title] = task

        self.ensure_entry(
            employee1.employee_profile,
            tasks["Оформлення документів"],
            today - timedelta(days=1),
            Decimal("2.50"),
            TimeEntry.Status.SUBMITTED,
            manager,
            "Перевірено комплект документів для відправлення.",
        )
        self.ensure_entry(
            employee2.employee_profile,
            tasks["Контроль доставки"],
            today - timedelta(days=2),
            Decimal("7.75"),
            TimeEntry.Status.APPROVED,
            manager,
            "Контроль завантаження та першої ділянки маршруту.",
        )
        self.ensure_entry(
            employee1.employee_profile,
            tasks["Планування маршруту"],
            today,
            Decimal("1.25"),
            TimeEntry.Status.DRAFT,
            manager,
            "Актуалізація маршруту через дорожні обмеження.",
        )

        self.stdout.write(self.style.SUCCESS("Демонстраційні дані LogiTime готові."))
        for label, user in (
            ("Адміністратор", admin),
            ("Менеджер", manager),
            ("Працівник", employee1),
            ("Водій", employee2),
            ("Бухгалтер", accountant),
        ):
            self.stdout.write(f"{label}: {user.username} / {DEMO_PASSWORD}")

    def ensure_user(self, username, role, position, number, rate):
        user, _ = User.objects.update_or_create(
            username=username,
            defaults={
                "email": f"{username}@logitime.example",
                "role": role,
                "is_staff": role == User.Role.ADMIN,
                "is_active": True,
            },
        )
        if not user.check_password(DEMO_PASSWORD):
            user.set_password(DEMO_PASSWORD)
            user.save(update_fields=("password",))
        if role != User.Role.ADMIN:
            first_name, last_name = {
                "demo_manager": ("Олена", "Коваль"),
                "demo_employee": ("Андрій", "Мельник"),
                "demo_driver": ("Сергій", "Бондар"),
                "demo_accountant": ("Ірина", "Ткаченко"),
            }[username]
            EmployeeProfile.objects.update_or_create(
                user=user,
                defaults={
                    "first_name": first_name,
                    "last_name": last_name,
                    "patronymic": "",
                    "employee_number": number,
                    "position": position,
                    "hourly_rate": rate,
                    "is_active": True,
                },
            )
        return user

    def ensure_entry(self, employee, task, work_date, hours, status, manager, comment):
        entry = TimeEntry.objects.filter(employee=employee, task=task, work_date=work_date).first()
        if entry:
            return entry
        entry = TimeEntry(employee=employee, task=task, work_date=work_date, hours=hours, comment=comment)
        entry.save()
        TimeEntryHistory.objects.create(
            entry=entry,
            action=TimeEntryHistory.Action.CREATE,
            actor=employee.user,
            old_status="",
            new_status=entry.status,
            snapshot={"hours": str(entry.hours), "cost": str(entry.cost)},
        )
        if status in {TimeEntry.Status.SUBMITTED, TimeEntry.Status.APPROVED}:
            entry.submit(employee.user)
        if status == TimeEntry.Status.APPROVED:
            entry.review(manager, approve=True, note="Демонстраційне погодження.")
        return entry
