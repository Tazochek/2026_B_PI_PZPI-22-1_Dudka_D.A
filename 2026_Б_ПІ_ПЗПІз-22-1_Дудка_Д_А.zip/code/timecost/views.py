from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import User
from accounts.permissions import role_required

from .forms import ReportFilterForm, ReviewForm, TimeEntryForm
from .models import TimeEntry, TimeEntryHistory
from .reports import build_time_cost_report


def report_entries_for_user(user):
    entries = TimeEntry.objects.select_related(
        "employee__user", "task__order__client", "task__order__manager"
    )
    if user.role in {User.Role.ADMIN, User.Role.ACCOUNTANT}:
        return entries
    if user.role == User.Role.MANAGER:
        return entries.filter(task__order__manager=user)
    return entries.filter(employee__user=user)


@role_required(User.Role.EMPLOYEE)
def my_entries(request):
    entries = report_entries_for_user(request.user)
    return render(request, "timecost/my_entries.html", {"entries": entries})


@role_required(User.Role.EMPLOYEE)
def entry_create(request):
    employee = request.user.employee_profile
    form = TimeEntryForm(request.POST or None, employee=employee)
    if request.method == "POST" and form.is_valid():
        entry = form.save()
        TimeEntryHistory.objects.create(
            entry=entry,
            action=TimeEntryHistory.Action.CREATE,
            actor=request.user,
            old_status="",
            new_status=entry.status,
            snapshot={"hours": str(entry.hours), "cost": str(entry.cost)},
        )
        messages.success(request, "Запис часу збережено як чернетку.")
        return redirect("timecost:my_entries")
    return render(request, "timecost/entry_form.html", {"form": form, "title": "Новий запис часу"})


@role_required(User.Role.EMPLOYEE)
def entry_update(request, pk):
    entry = get_object_or_404(TimeEntry, pk=pk, employee__user=request.user)
    if entry.status not in {TimeEntry.Status.DRAFT, TimeEntry.Status.REJECTED}:
        messages.error(request, "Редагувати можна лише чернетку або відхилений запис.")
        return redirect("timecost:my_entries")
    form = TimeEntryForm(request.POST or None, instance=entry, employee=entry.employee)
    if request.method == "POST" and form.is_valid():
        updated = form.save()
        TimeEntryHistory.objects.create(
            entry=updated,
            action=TimeEntryHistory.Action.UPDATE,
            actor=request.user,
            old_status=entry.status,
            new_status=updated.status,
            snapshot={"hours": str(updated.hours), "cost": str(updated.cost)},
        )
        messages.success(request, "Запис часу оновлено.")
        return redirect("timecost:my_entries")
    return render(request, "timecost/entry_form.html", {"form": form, "title": "Редагування запису часу"})


@role_required(User.Role.EMPLOYEE)
def entry_submit(request, pk):
    if request.method != "POST":
        return redirect("timecost:my_entries")
    entry = get_object_or_404(TimeEntry, pk=pk, employee__user=request.user)
    try:
        entry.submit(request.user)
        messages.success(request, "Запис подано менеджеру на погодження.")
    except ValidationError as error:
        messages.error(request, "; ".join(error.messages))
    return redirect("timecost:my_entries")


@role_required(User.Role.ADMIN, User.Role.MANAGER)
def approvals(request):
    entries = report_entries_for_user(request.user).filter(status=TimeEntry.Status.SUBMITTED)
    return render(request, "timecost/approvals.html", {"entries": entries})


@role_required(User.Role.ADMIN, User.Role.MANAGER)
def entry_review(request, pk):
    entry = get_object_or_404(
        report_entries_for_user(request.user), pk=pk, status=TimeEntry.Status.SUBMITTED
    )
    form = ReviewForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            entry.review(
                request.user,
                approve=form.cleaned_data["decision"] == "approve",
                note=form.cleaned_data["note"],
            )
            messages.success(request, "Рішення щодо запису збережено.")
            return redirect("timecost:approvals")
        except ValidationError as error:
            form.add_error(None, "; ".join(error.messages))
    return render(request, "timecost/review.html", {"entry": entry, "form": form})


@role_required(User.Role.ADMIN, User.Role.MANAGER, User.Role.ACCOUNTANT)
def report(request):
    form = ReportFilterForm(request.GET or None)
    entries = report_entries_for_user(request.user)
    if form.is_valid():
        data = form.cleaned_data
        if data.get("date_from"):
            entries = entries.filter(work_date__gte=data["date_from"])
        if data.get("date_to"):
            entries = entries.filter(work_date__lte=data["date_to"])
        if data.get("status"):
            entries = entries.filter(status=data["status"])
    totals = entries.aggregate(hours=Sum("hours"), cost=Sum("cost"))
    return render(
        request,
        "timecost/report.html",
        {"form": form, "entries": entries, "total_hours": totals["hours"] or 0, "total_cost": totals["cost"] or 0},
    )


@role_required(User.Role.ADMIN, User.Role.MANAGER, User.Role.ACCOUNTANT)
def report_xlsx(request):
    form = ReportFilterForm(request.GET or None)
    entries = report_entries_for_user(request.user)
    if form.is_valid():
        data = form.cleaned_data
        if data.get("date_from"):
            entries = entries.filter(work_date__gte=data["date_from"])
        if data.get("date_to"):
            entries = entries.filter(work_date__lte=data["date_to"])
        if data.get("status"):
            entries = entries.filter(status=data["status"])
    response = HttpResponse(
        build_time_cost_report(entries.order_by("work_date", "task__order__order_number")),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    response["Content-Disposition"] = 'attachment; filename="time-cost-report.xlsx"'
    return response
