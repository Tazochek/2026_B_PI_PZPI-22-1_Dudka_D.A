from decimal import Decimal, ROUND_HALF_UP

from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Q
from django.utils import timezone


class TimeEntry(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Чернетка"
        SUBMITTED = "submitted", "На погодженні"
        APPROVED = "approved", "Погоджено"
        REJECTED = "rejected", "Відхилено"

    employee = models.ForeignKey(
        "accounts.EmployeeProfile",
        on_delete=models.PROTECT,
        related_name="time_entries",
        verbose_name="працівник",
    )
    task = models.ForeignKey(
        "operations.OrderTask",
        on_delete=models.PROTECT,
        related_name="time_entries",
        verbose_name="задача",
    )
    work_date = models.DateField("дата роботи")
    hours = models.DecimalField("витрачено годин", max_digits=5, decimal_places=2)
    hourly_rate_snapshot = models.DecimalField(
        "ставка на момент запису", max_digits=10, decimal_places=2, editable=False
    )
    cost = models.DecimalField(
        "вартість часу", max_digits=12, decimal_places=2, editable=False
    )
    comment = models.TextField("коментар", blank=True)
    status = models.CharField(
        "статус", max_length=12, choices=Status.choices, default=Status.DRAFT
    )
    submitted_at = models.DateTimeField("подано", null=True, blank=True)
    reviewed_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.PROTECT,
        related_name="reviewed_time_entries",
        verbose_name="перевірив",
        null=True,
        blank=True,
    )
    reviewed_at = models.DateTimeField("перевірено", null=True, blank=True)
    review_comment = models.TextField("коментар перевірки", blank=True)
    created_at = models.DateTimeField("створено", auto_now_add=True)
    updated_at = models.DateTimeField("оновлено", auto_now=True)

    class Meta:
        db_table = "timecost_timeentry"
        ordering = ("-work_date", "-created_at")
        verbose_name = "запис витрат часу"
        verbose_name_plural = "записи витрат часу"
        constraints = [
            models.CheckConstraint(
                condition=Q(hours__gt=Decimal("0")) & Q(hours__lte=Decimal("24")),
                name="time_entry_hours_range",
            ),
            models.CheckConstraint(
                condition=Q(hourly_rate_snapshot__gte=Decimal("0")),
                name="time_entry_rate_nonnegative",
            ),
            models.CheckConstraint(
                condition=Q(cost__gte=Decimal("0")), name="time_entry_cost_nonnegative"
            ),
        ]
        indexes = [
            models.Index(fields=("status", "work_date"), name="entry_status_date_idx"),
            models.Index(fields=("employee", "work_date"), name="entry_employee_date_idx"),
        ]

    def clean(self):
        errors = {}
        if self.hours is not None and not (Decimal("0") < self.hours <= Decimal("24")):
            errors["hours"] = "Кількість годин має бути більшою за 0 та не перевищувати 24."
        if self.employee_id and self.task_id:
            assigned = self.task.order.assigned_employees.filter(pk=self.employee_id).exists()
            if not assigned:
                errors["task"] = "Працівника не призначено до цього замовлення."
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        if self.pk:
            previous = TimeEntry.objects.filter(pk=self.pk).only("status").first()
            if previous and previous.status == self.Status.APPROVED:
                raise ValidationError("Погоджений запис не можна змінювати.")
        if not self.hourly_rate_snapshot:
            self.hourly_rate_snapshot = self.employee.hourly_rate
        self.cost = (self.hours * self.hourly_rate_snapshot).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        self.full_clean()
        return super().save(*args, **kwargs)

    def _history(self, action, actor, old_status, note=""):
        TimeEntryHistory.objects.create(
            entry=self,
            action=action,
            actor=actor,
            old_status=old_status,
            new_status=self.status,
            note=note,
            snapshot={
                "hours": str(self.hours),
                "rate": str(self.hourly_rate_snapshot),
                "cost": str(self.cost),
                "work_date": self.work_date.isoformat(),
            },
        )

    @transaction.atomic
    def submit(self, actor):
        if actor != self.employee.user or self.status not in {
            self.Status.DRAFT,
            self.Status.REJECTED,
        }:
            raise ValidationError("Цей запис не можна подати на погодження.")
        old_status = self.status
        self.status = self.Status.SUBMITTED
        self.submitted_at = timezone.now()
        self.review_comment = ""
        self.save()
        self._history(TimeEntryHistory.Action.SUBMIT, actor, old_status)

    @transaction.atomic
    def review(self, actor, *, approve, note=""):
        if self.status != self.Status.SUBMITTED:
            raise ValidationError("Перевіряти можна лише подані записи.")
        if actor.role not in {actor.Role.ADMIN, actor.Role.MANAGER}:
            raise ValidationError("Недостатньо прав для погодження запису.")
        if actor.role == actor.Role.MANAGER and self.task.order.manager_id != actor.pk:
            raise ValidationError("Менеджер може погоджувати лише власні замовлення.")
        old_status = self.status
        self.status = self.Status.APPROVED if approve else self.Status.REJECTED
        self.reviewed_by = actor
        self.reviewed_at = timezone.now()
        self.review_comment = note
        # Bypass the approved immutability guard for this state transition only.
        self.full_clean()
        models.Model.save(self)
        action = TimeEntryHistory.Action.APPROVE if approve else TimeEntryHistory.Action.REJECT
        self._history(action, actor, old_status, note)

    def __str__(self):
        return f"{self.employee.full_name}: {self.hours} год. — {self.task}"


class TimeEntryHistory(models.Model):
    class Action(models.TextChoices):
        CREATE = "create", "Створено"
        UPDATE = "update", "Оновлено"
        SUBMIT = "submit", "Подано"
        APPROVE = "approve", "Погоджено"
        REJECT = "reject", "Відхилено"

    entry = models.ForeignKey(
        TimeEntry,
        on_delete=models.CASCADE,
        related_name="history",
        verbose_name="запис часу",
    )
    action = models.CharField("дія", max_length=12, choices=Action.choices)
    actor = models.ForeignKey(
        "accounts.User",
        on_delete=models.PROTECT,
        related_name="time_entry_actions",
        verbose_name="виконавець",
    )
    old_status = models.CharField("попередній статус", max_length=12, blank=True)
    new_status = models.CharField("новий статус", max_length=12)
    note = models.TextField("примітка", blank=True)
    snapshot = models.JSONField("знімок даних", default=dict)
    created_at = models.DateTimeField("час події", auto_now_add=True)

    class Meta:
        db_table = "timecost_timeentryhistory"
        ordering = ("-created_at",)
        verbose_name = "подія аудиту"
        verbose_name_plural = "події аудиту"

    def __str__(self):
        return f"{self.get_action_display()}: {self.entry_id}"
