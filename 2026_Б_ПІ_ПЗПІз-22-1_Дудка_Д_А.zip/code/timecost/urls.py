from django.urls import path

from . import views

app_name = "timecost"

urlpatterns = [
    path("my/", views.my_entries, name="my_entries"),
    path("entries/create/", views.entry_create, name="entry_create"),
    path("entries/<int:pk>/edit/", views.entry_update, name="entry_update"),
    path("entries/<int:pk>/submit/", views.entry_submit, name="entry_submit"),
    path("approvals/", views.approvals, name="approvals"),
    path("approvals/<int:pk>/", views.entry_review, name="entry_review"),
    path("report/", views.report, name="report"),
    path("report.xlsx", views.report_xlsx, name="report_xlsx"),
]
