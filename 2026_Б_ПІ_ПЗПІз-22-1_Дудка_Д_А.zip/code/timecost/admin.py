from django.contrib import admin

from .models import TimeEntry, TimeEntryHistory


@admin.register(TimeEntry)
class TimeEntryAdmin(admin.ModelAdmin):
    list_display = ("work_date", "employee", "task", "hours", "cost", "status")
    list_filter = ("status", "work_date")
    search_fields = ("employee__last_name", "task__title", "task__order__order_number")
    readonly_fields = ("hourly_rate_snapshot", "cost", "submitted_at", "reviewed_at")


@admin.register(TimeEntryHistory)
class TimeEntryHistoryAdmin(admin.ModelAdmin):
    list_display = ("entry", "action", "actor", "old_status", "new_status", "created_at")
    readonly_fields = ("entry", "action", "actor", "old_status", "new_status", "note", "snapshot", "created_at")
