from django.urls import reverse

from timecost.tests.base import LogisticsTestCase


class OrderPermissionTests(LogisticsTestCase):
    def test_assigned_employee_can_open_order(self):
        self.client.force_login(self.employee)
        response = self.client.get(reverse("operations:order_detail", args=(self.order.pk,)))
        self.assertEqual(response.status_code, 200)

    def test_unassigned_employee_gets_404(self):
        self.client.force_login(self.other_employee)
        response = self.client.get(reverse("operations:order_detail", args=(self.order.pk,)))
        self.assertEqual(response.status_code, 404)

    def test_foreign_manager_gets_404(self):
        self.client.force_login(self.other_manager)
        response = self.client.get(reverse("operations:order_detail", args=(self.order.pk,)))
        self.assertEqual(response.status_code, 404)
