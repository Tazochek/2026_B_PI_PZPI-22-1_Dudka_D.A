from django.contrib import admin

from .models import Client, LogisticsOrder, OrderTask


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ("name", "tax_id", "contact_person")
    search_fields = ("name", "tax_id")


@admin.register(LogisticsOrder)
class LogisticsOrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "client", "route", "status", "manager", "planned_start")
    list_filter = ("status", "planned_start")
    search_fields = ("order_number", "client__name", "route")
    filter_horizontal = ("assigned_employees",)


@admin.register(OrderTask)
class OrderTaskAdmin(admin.ModelAdmin):
    list_display = ("title", "order", "status", "estimated_hours")
    list_filter = ("status",)
    search_fields = ("title", "order__order_number")
