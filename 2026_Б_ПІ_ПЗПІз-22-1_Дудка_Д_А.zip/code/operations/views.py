from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import User
from accounts.permissions import role_required

from .forms import ClientForm, LogisticsOrderForm, OrderTaskForm
from .models import Client, LogisticsOrder


def orders_for_user(user):
    orders = LogisticsOrder.objects.select_related("client", "manager").prefetch_related(
        "assigned_employees__user", "tasks"
    )
    if user.role in {User.Role.ADMIN, User.Role.ACCOUNTANT}:
        return orders
    if user.role == User.Role.MANAGER:
        return orders.filter(manager=user)
    return orders.filter(assigned_employees__user=user).distinct()


@role_required(User.Role.ADMIN, User.Role.MANAGER, User.Role.EMPLOYEE, User.Role.ACCOUNTANT)
def order_list(request):
    return render(request, "operations/order_list.html", {"orders": orders_for_user(request.user)})


@role_required(User.Role.ADMIN, User.Role.MANAGER, User.Role.EMPLOYEE, User.Role.ACCOUNTANT)
def order_detail(request, pk):
    order = get_object_or_404(orders_for_user(request.user), pk=pk)
    entries = order.tasks.select_related("order").prefetch_related("time_entries")
    return render(request, "operations/order_detail.html", {"order": order, "tasks": entries})


@role_required(User.Role.ADMIN, User.Role.MANAGER)
def order_create(request):
    form = LogisticsOrderForm(request.POST or None, current_user=request.user)
    if request.method == "POST" and form.is_valid():
        order = form.save()
        messages.success(request, f"Замовлення {order.order_number} створено.")
        return redirect("operations:order_detail", pk=order.pk)
    return render(request, "operations/form.html", {"form": form, "title": "Нове замовлення"})


@role_required(User.Role.ADMIN, User.Role.MANAGER)
def order_update(request, pk):
    order = get_object_or_404(orders_for_user(request.user), pk=pk)
    form = LogisticsOrderForm(request.POST or None, instance=order, current_user=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Замовлення оновлено.")
        return redirect("operations:order_detail", pk=order.pk)
    return render(request, "operations/form.html", {"form": form, "title": f"Замовлення {order.order_number}"})


@role_required(User.Role.ADMIN, User.Role.MANAGER)
def task_create(request, order_pk):
    order = get_object_or_404(orders_for_user(request.user), pk=order_pk)
    form = OrderTaskForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        task = form.save(commit=False)
        task.order = order
        task.full_clean()
        task.save()
        messages.success(request, "Задачу додано до замовлення.")
        return redirect("operations:order_detail", pk=order.pk)
    return render(request, "operations/form.html", {"form": form, "title": f"Нова задача — {order.order_number}"})


@role_required(User.Role.ADMIN)
def client_list(request):
    return render(request, "operations/client_list.html", {"clients": Client.objects.all()})


@role_required(User.Role.ADMIN)
def client_create(request):
    form = ClientForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Клієнта створено.")
        return redirect("operations:client_list")
    return render(request, "operations/form.html", {"form": form, "title": "Новий клієнт"})
