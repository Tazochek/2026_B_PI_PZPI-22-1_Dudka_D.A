from django import forms

from accounts.models import EmployeeProfile, User

from .models import Client, LogisticsOrder, OrderTask


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ("name", "tax_id", "contact_person", "phone", "email")


class LogisticsOrderForm(forms.ModelForm):
    class Meta:
        model = LogisticsOrder
        fields = (
            "order_number",
            "client",
            "route",
            "description",
            "status",
            "manager",
            "assigned_employees",
            "planned_start",
            "planned_end",
        )
        widgets = {
            "planned_start": forms.DateInput(attrs={"type": "date"}),
            "planned_end": forms.DateInput(attrs={"type": "date"}),
            "description": forms.Textarea(attrs={"rows": 3}),
            "assigned_employees": forms.SelectMultiple(attrs={"size": 7}),
        }

    def __init__(self, *args, current_user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["manager"].queryset = User.objects.filter(
            role__in=(User.Role.MANAGER, User.Role.ADMIN), is_active=True
        )
        self.fields["assigned_employees"].queryset = EmployeeProfile.objects.filter(
            is_active=True,
            user__role__in=(User.Role.EMPLOYEE, User.Role.MANAGER),
        ).select_related("user")
        if current_user and current_user.role == User.Role.MANAGER:
            self.fields["manager"].queryset = User.objects.filter(pk=current_user.pk)
            self.fields["manager"].initial = current_user


class OrderTaskForm(forms.ModelForm):
    class Meta:
        model = OrderTask
        fields = ("title", "description", "estimated_hours", "status")
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}
