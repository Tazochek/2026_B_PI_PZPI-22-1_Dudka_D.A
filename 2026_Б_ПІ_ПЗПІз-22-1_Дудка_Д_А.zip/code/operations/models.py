from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q


class Client(models.Model):
    name = models.CharField("назва клієнта", max_length=255, unique=True)
    tax_id = models.CharField("код ЄДРПОУ", max_length=12, blank=True)
    contact_person = models.CharField("контактна особа", max_length=255, blank=True)
    phone = models.CharField("телефон", max_length=30, blank=True)
    email = models.EmailField("електронна пошта", blank=True)

    class Meta:
        db_table = "operations_client"
        ordering = ("name",)
        verbose_name = "клієнт"
        verbose_name_plural = "клієнти"

    def __str__(self):
        return self.name


class LogisticsOrder(models.Model):
    class Status(models.TextChoices):
        PLANNED = "planned", "Заплановано"
        IN_PROGRESS = "in_progress", "Виконується"
        COMPLETED = "completed", "Завершено"
        CANCELLED = "cancelled", "Скасовано"

    order_number = models.CharField("номер замовлення", max_length=40, unique=True)
    client = models.ForeignKey(
        Client, on_delete=models.PROTECT, related_name="orders", verbose_name="клієнт"
    )
    route = models.CharField("маршрут", max_length=255)
    description = models.TextField("опис", blank=True)
    status = models.CharField(
        "статус", max_length=20, choices=Status.choices, default=Status.PLANNED
    )
    manager = models.ForeignKey(
        "accounts.User",
        on_delete=models.PROTECT,
        related_name="managed_orders",
        verbose_name="відповідальний менеджер",
    )
    assigned_employees = models.ManyToManyField(
        "accounts.EmployeeProfile",
        related_name="orders",
        verbose_name="призначені працівники",
        blank=True,
    )
    planned_start = models.DateField("плановий початок")
    planned_end = models.DateField("планове завершення")
    created_at = models.DateTimeField("створено", auto_now_add=True)

    class Meta:
        db_table = "operations_logisticsorder"
        ordering = ("-planned_start", "order_number")
        verbose_name = "логістичне замовлення"
        verbose_name_plural = "логістичні замовлення"
        indexes = [
            models.Index(fields=("status", "planned_start"), name="order_status_start_idx"),
            models.Index(fields=("manager",), name="order_manager_idx"),
        ]

    def clean(self):
        errors = {}
        if self.planned_start and self.planned_end and self.planned_end < self.planned_start:
            errors["planned_end"] = "Дата завершення не може передувати початку."
        if self.manager_id and self.manager.role not in {
            self.manager.Role.MANAGER,
            self.manager.Role.ADMIN,
        }:
            errors["manager"] = "Замовлення може вести менеджер або адміністратор."
        if errors:
            raise ValidationError(errors)

    def __str__(self):
        return f"{self.order_number} — {self.client.name}"


class OrderTask(models.Model):
    class Status(models.TextChoices):
        OPEN = "open", "Відкрита"
        IN_PROGRESS = "in_progress", "Виконується"
        DONE = "done", "Виконана"

    order = models.ForeignKey(
        LogisticsOrder,
        on_delete=models.PROTECT,
        related_name="tasks",
        verbose_name="замовлення",
    )
    title = models.CharField("назва задачі", max_length=255)
    description = models.TextField("опис", blank=True)
    estimated_hours = models.DecimalField(
        "планові години", max_digits=7, decimal_places=2, default=Decimal("1.00")
    )
    status = models.CharField(
        "статус", max_length=20, choices=Status.choices, default=Status.OPEN
    )

    class Meta:
        db_table = "operations_ordertask"
        ordering = ("order__order_number", "title")
        verbose_name = "задача замовлення"
        verbose_name_plural = "задачі замовлення"
        constraints = [
            models.UniqueConstraint(
                fields=("order", "title"), name="unique_task_title_per_order"
            ),
            models.CheckConstraint(
                condition=Q(estimated_hours__gt=Decimal("0")),
                name="task_estimated_hours_positive",
            ),
        ]

    def __str__(self):
        return f"{self.order.order_number}: {self.title}"
