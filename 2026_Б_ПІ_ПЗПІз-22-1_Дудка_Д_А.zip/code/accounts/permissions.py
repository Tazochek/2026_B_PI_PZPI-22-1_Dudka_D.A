from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def role_required(*allowed_roles):
    """Перевіряє тип дії, а доступ до конкретних об'єктів лишає queryset."""

    def decorator(view_function):
        @login_required
        @wraps(view_function)
        def wrapped_view(request, *args, **kwargs):
            if request.user.role not in allowed_roles:
                raise PermissionDenied("Недостатньо прав для цієї дії.")
            return view_function(request, *args, **kwargs)

        return wrapped_view

    return decorator

