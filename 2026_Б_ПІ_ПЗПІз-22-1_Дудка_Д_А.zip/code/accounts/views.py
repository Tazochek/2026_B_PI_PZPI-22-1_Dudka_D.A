from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import redirect, render

from operations.models import LogisticsOrder
from timecost.models import TimeEntry

from .forms import AccountCreationForm
from .models import User
from .permissions import role_required


@login_required
def dashboard(request):
    user = request.user
    entries = TimeEntry.objects.none()
    orders = LogisticsOrder.objects.none()
    if user.role == User.Role.EMPLOYEE:
        entries = TimeEntry.objects.filter(employee__user=user)
        orders = LogisticsOrder.objects.filter(assigned_employees__user=user).distinct()
    elif user.role == User.Role.MANAGER:
        orders = LogisticsOrder.objects.filter(manager=user)
        entries = TimeEntry.objects.filter(task__order__manager=user)
    elif user.role in {User.Role.ADMIN, User.Role.ACCOUNTANT}:
        orders = LogisticsOrder.objects.all()
        entries = TimeEntry.objects.all()

    context = {
        "orders_count": orders.count(),
        "entries_count": entries.count(),
        "pending_count": entries.filter(status=TimeEntry.Status.SUBMITTED).count(),
        "approved_hours": entries.filter(status=TimeEntry.Status.APPROVED).aggregate(
            total=Sum("hours")
        )["total"]
        or 0,
        "recent_entries": entries.select_related(
            "employee__user", "task__order"
        ).order_by("-work_date", "-created_at")[:6],
    }
    return render(request, "accounts/dashboard.html", context)


@role_required(User.Role.ADMIN)
def create_account(request):
    form = AccountCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        created_user = form.save()
        messages.success(request, f"Обліковий запис {created_user.username} створено.")
        return redirect("accounts:dashboard")
    return render(request, "accounts/account_form.html", {"form": form})
