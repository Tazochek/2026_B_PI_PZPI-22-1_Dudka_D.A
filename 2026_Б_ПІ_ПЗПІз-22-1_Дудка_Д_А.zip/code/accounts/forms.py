from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import EmployeeProfile, User


class AccountCreationForm(UserCreationForm):
    first_name = forms.CharField(label="Ім'я", max_length=150, required=False)
    last_name = forms.CharField(label="Прізвище", max_length=150, required=False)
    patronymic = forms.CharField(label="По батькові", max_length=150, required=False)
    employee_number = forms.CharField(
        label="Табельний номер", max_length=30, required=False
    )
    position = forms.CharField(label="Посада", max_length=150, required=False)
    hourly_rate = forms.DecimalField(
        label="Погодинна ставка, грн",
        min_value=0,
        max_digits=10,
        decimal_places=2,
        required=False,
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email", "role", "password1", "password2")

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get("role")
        if role and role != User.Role.ADMIN:
            for field_name in (
                "first_name",
                "last_name",
                "employee_number",
                "position",
                "hourly_rate",
            ):
                if cleaned_data.get(field_name) in (None, ""):
                    self.add_error(field_name, "Це поле обов'язкове для працівника.")
        number = cleaned_data.get("employee_number")
        if number and EmployeeProfile.objects.filter(employee_number=number).exists():
            self.add_error("employee_number", "Такий табельний номер вже існує.")
        return cleaned_data

    def save(self, commit=True):
        if not commit:
            raise ValueError("Форма підтримує лише атомарне збереження.")
        role = self.cleaned_data["role"]
        profile_data = None
        if role != User.Role.ADMIN:
            profile_data = {
                "first_name": self.cleaned_data["first_name"],
                "last_name": self.cleaned_data["last_name"],
                "patronymic": self.cleaned_data.get("patronymic", ""),
                "employee_number": self.cleaned_data["employee_number"],
                "position": self.cleaned_data["position"],
                "hourly_rate": self.cleaned_data["hourly_rate"],
            }
        return User.objects.create_account(
            username=self.cleaned_data["username"],
            email=self.cleaned_data["email"],
            password=self.cleaned_data["password1"],
            role=role,
            profile_data=profile_data,
        )
