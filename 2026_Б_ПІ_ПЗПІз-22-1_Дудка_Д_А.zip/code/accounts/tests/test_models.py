from decimal import Decimal

from django.test import TestCase

from accounts.models import EmployeeProfile, User


class AccountModelTests(TestCase):
    def test_employee_account_is_created_with_profile_atomically(self):
        user = User.objects.create_account(
            username="employee",
            email="employee@example.com",
            password="StrongPass2026!",
            role=User.Role.EMPLOYEE,
            profile_data={
                "first_name": "Андрій",
                "last_name": "Мельник",
                "employee_number": "EMP-100",
                "position": "Логіст",
                "hourly_rate": Decimal("250.00"),
            },
        )
        self.assertEqual(user.employee_profile.employee_number, "EMP-100")
        self.assertEqual(EmployeeProfile.objects.count(), 1)

    def test_admin_has_no_employee_profile(self):
        user = User.objects.create_account(
            username="admin",
            email="admin@example.com",
            password="StrongPass2026!",
            role=User.Role.ADMIN,
        )
        self.assertFalse(EmployeeProfile.objects.filter(user=user).exists())
