from decimal import Decimal

from django.contrib.auth.models import AbstractUser, UserManager
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Q


class AccountUserManager(UserManager):
    """Creates a user and the role-specific employee profile atomically."""

    @transaction.atomic
    def create_account(self, *, username, email, password, role, profile_data=None):
        if role not in User.Role.values:
            raise ValueError("Невідома роль користувача.")

        user = self.create_user(
            username=username,
            email=email,
            password=password,
            role=role,
            is_staff=role == User.Role.ADMIN,
        )
        if role != User.Role.ADMIN:
            profile = EmployeeProfile(user=user, **(profile_data or {}))
            profile.full_clean()
            profile.save()
        user.validate_role_profile()
        return user

    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault("role", User.Role.ADMIN)
        if extra_fields.get("role") != User.Role.ADMIN:
            raise ValueError("Суперкористувач повинен мати роль адміністратора.")
        return super().create_superuser(username, email, password, **extra_fields)


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Адміністратор"
        MANAGER = "manager", "Менеджер"
        EMPLOYEE = "employee", "Працівник"
        ACCOUNTANT = "accountant", "Бухгалтер"

    first_name = None
    last_name = None
    email = models.EmailField("електронна пошта", unique=True)
    role = models.CharField(
        "роль", max_length=12, choices=Role.choices, default=Role.EMPLOYEE
    )

    objects = AccountUserManager()

    class Meta:
        db_table = "accounts_user"
        verbose_name = "користувач"
        verbose_name_plural = "користувачі"

    def validate_role_profile(self):
        has_profile = EmployeeProfile.objects.filter(user=self).exists()
        if (self.role == self.Role.ADMIN and has_profile) or (
            self.role != self.Role.ADMIN and not has_profile
        ):
            raise ValidationError("Роль користувача не узгоджена з профілем працівника.")


class EmployeeProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="employee_profile",
        verbose_name="користувач",
    )
    first_name = models.CharField("ім'я", max_length=150)
    last_name = models.CharField("прізвище", max_length=150)
    patronymic = models.CharField("по батькові", max_length=150, blank=True)
    employee_number = models.CharField(
        "табельний номер", max_length=30, unique=True
    )
    position = models.CharField("посада", max_length=150)
    hourly_rate = models.DecimalField(
        "погодинна ставка, грн", max_digits=10, decimal_places=2
    )
    is_active = models.BooleanField("активний працівник", default=True)

    class Meta:
        db_table = "accounts_employeeprofile"
        ordering = ("last_name", "first_name")
        verbose_name = "профіль працівника"
        verbose_name_plural = "профілі працівників"
        constraints = [
            models.CheckConstraint(
                condition=Q(hourly_rate__gte=Decimal("0")),
                name="employee_hourly_rate_nonnegative",
            )
        ]

    def clean(self):
        if self.user_id and self.user.role == User.Role.ADMIN:
            raise ValidationError(
                {"user": "Адміністратор не повинен мати профіль працівника."}
            )
        if self.hourly_rate is not None and self.hourly_rate < 0:
            raise ValidationError({"hourly_rate": "Ставка не може бути від'ємною."})

    @property
    def full_name(self):
        return " ".join(
            part for part in (self.last_name, self.first_name, self.patronymic) if part
        )

    def __str__(self):
        return f"{self.full_name} ({self.employee_number})"
