from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import EmployeeProfile, User


@admin.register(User)
class AccountUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("Роль", {"fields": ("role",)}),)
    add_fieldsets = UserAdmin.add_fieldsets + (("Роль", {"fields": ("email", "role")}),)
    list_display = ("username", "email", "role", "is_active", "is_staff")
    list_filter = ("role", "is_active", "is_staff")


@admin.register(EmployeeProfile)
class EmployeeProfileAdmin(admin.ModelAdmin):
    list_display = ("employee_number", "full_name", "position", "hourly_rate", "is_active")
    search_fields = ("employee_number", "first_name", "last_name")
    list_filter = ("is_active", "user__role")
