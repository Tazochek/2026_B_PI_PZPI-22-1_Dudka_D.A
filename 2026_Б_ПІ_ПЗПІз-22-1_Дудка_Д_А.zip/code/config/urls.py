from django.contrib import admin
from django.urls import include, path


urlpatterns = [
    path("admin/", admin.site.urls),
    path("operations/", include("operations.urls")),
    path("time/", include("timecost.urls")),
    path("", include("accounts.urls")),
]
